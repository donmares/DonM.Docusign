﻿
namespace DonM.Docusign.Library.Interfaces
{
    public interface IFileReader
    {
        string ReadAll(string fileName);
    }
}
